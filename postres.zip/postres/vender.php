<?php
$precios = [
    1 => 6000, 
    2 => 10000, 
    3 => 20000 
];
$tipo = $_POST['tipo'];
$cantidad = $_POST['cantidad'];
$lugar = $_POST['lugar'];
$chispitas = $_POST['chispitas'];

$precioBase = $precios[$tipo] * $cantidad;

$costoAdicional = 0;
if ($lugar == 1) { 
    $costoAdicional = $costoAdicional + 1000 * $cantidad; 
}

if ($chispitas == 1) { 
    $costoAdicional + 2000 * $cantidad;; 
}

$total = $precioBase + $costoAdicional;


echo $total;
?>